import {
    jsx as _jsx
} from "react/jsx-runtime";
import * as React from "react";
import gsap from "gsap";
import {
    ScrollTrigger
} from "gsap/ScrollTrigger";
import SplitType from "split-type";
gsap.registerPlugin(ScrollTrigger);
export function TextReveal() {
    const textRef = React.useRef(null);
    React.useEffect(() => {
        const textElement = textRef.current;
        if (!textElement) return;
        const sentences = textElement.querySelectorAll("h1, h2, h3, h4, h5, h6, p");
        const characters = [];
        sentences.forEach(sentence => {
            const splitText = new SplitType(sentence, {
                types: "words,chars"
            });
            splitText.words.forEach(wordEl => {
                wordEl.style.whiteSpace = "nowrap";
            });
            characters.push(...Array.from(splitText.chars));
        });
        gsap.set(characters, {
            opacity: .3
        });
        const tl = gsap.timeline({
            scrollTrigger: {
                trigger: textElement,
                start: "top 90%",
                end: "bottom 50%",
                scrub: true
            }
        });
        characters.forEach(char => {
            tl.to(char, {
                opacity: 1,
                duration: 2,
                ease: "ease-in-out"
            });
        }); // ✅ Observe DOM changes and refresh ScrollTrigger
        const observer = new MutationObserver(() => {
            ScrollTrigger.refresh();
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        return () => {
            tl.kill();
            observer.disconnect();
        };
    }, []);
    return {
        ref: textRef
    };
}
import {
    useContext as __legacyOverrideHOC_useContext
} from "react";
import {
    DataObserverContext as __legacyOverrideHOC_DataObserverContext
} from "framer";
export function withTextReveal(C) {
    return props => {
        __legacyOverrideHOC_useContext(__legacyOverrideHOC_DataObserverContext);
        return _jsx(C, { ...props,
            ...TextReveal(props)
        });
    };
}
withTextReveal.displayName = "TextReveal";
export const __FramerMetadata__ = {
    "exports": {
        "withTextReveal": {
            "type": "reactHoc",
            "name": "withTextReveal",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "TextReveal": {
            "type": "override",
            "name": "TextReveal",
            "annotations": {
                "framerContractVersion": "1"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}
//# sourceMappingURL=./Text_Highlight.map