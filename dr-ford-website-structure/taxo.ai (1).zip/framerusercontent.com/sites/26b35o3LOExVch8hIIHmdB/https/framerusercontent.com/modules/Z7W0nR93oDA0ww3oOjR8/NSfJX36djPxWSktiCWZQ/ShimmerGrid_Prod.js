import {
    jsx as _jsx,
    jsxs as _jsxs
} from "react/jsx-runtime";
import {
    addPropertyControls,
    ControlType,
    RenderTarget
} from "framer";
import FollowCursor from "https://framerusercontent.com/modules/QbIURI1CrWibjjH7k1PR/BJoalOj6ITiNp7UqoggC/FollowCursor_Prod.js";
import {
    cubicBezier
} from "framer-motion";
const ease = cubicBezier(.7, 0, .7, 1);
var Pattern;
(function(Pattern) {
    Pattern["Grid"] = "grid";
    Pattern["Checkerboard"] = "checkerboard";
    Pattern["HorizontalLines"] = "horizontalLines";
    Pattern["VerticalLines"] = "verticalLines";
    Pattern["DiagonalLines"] = "diagonalLines";
    Pattern["Dots"] = "dots";
    Pattern["Triangles"] = "triangles";
    Pattern["Custom"] = "custom";
})(Pattern || (Pattern = {}));
const IMAGE_SIZING_MAP = {
    fill: "cover",
    fit: "contain",
    stretch: "100% 100%"
};
const POSITION_MAP = {
    topLeft: "0 0",
    topCenter: "50% 0",
    topRight: "100% 0",
    left: "0 50%",
    center: "50% 50%",
    right: "100% 50%",
    bottomLeft: "0 100%",
    bottomCenter: "50% 100%",
    bottomRight: "100% 100%"
};
/**
 * @framerSupportedLayoutWidth fixed
 * @framerSupportedLayoutHeight fixed
 *
 * @framerDisableUnlink
 *
 * @framerIntrinsicWidth 400
 * @framerIntrinsicHeight 400
 */
export default function ShimmerGrid({
    color,
    hoverColor,
    hoverSize,
    hoverShape,
    patternPreset,
    flip,
    lineWidth,
    customPatternImage,
    customPatternSizing,
    tileSize,
    customPatternMode,
    customPatternPosition,
    dotSize,
    radius,
    smoothing,
    style
}) {
    const isCanvas = RenderTarget.current() === RenderTarget.canvas;
    const isCustom = patternPreset === "custom";
    const bgPosition = isCustom && customPatternSizing !== "stretch" ? POSITION_MAP[customPatternPosition] : POSITION_MAP.center;
    let bgImage = "";
    let bgSize = `${tileSize}px ${tileSize}px`;
    let bgRepeat = "repeat";
    switch (patternPreset) {
        case "grid":
            bgImage = `repeating-conic-gradient(at ${lineWidth}px ${lineWidth}px, [color] 0deg 90deg, transparent 90deg 180deg, [color] 180deg 360deg)`;
            break;
        case "checkerboard":
            bgImage = flip ? `repeating-conic-gradient([color] 0% 25%, transparent 0% 50%)` : `repeating-conic-gradient(transparent 0% 25%, [color] 0% 50%)`;
            break;
        case "horizontalLines":
            bgImage = `linear-gradient(to top, [color] ${lineWidth}px, transparent ${lineWidth}px)`;
            break;
        case "verticalLines":
            bgImage = `linear-gradient(to left, [color] ${lineWidth}px, transparent ${lineWidth}px)`;
            break;
        case "diagonalLines":
            const w = lineWidth / 2;
            const sideLength = getSideLength(tileSize * 2);
            bgImage = `linear-gradient(to top ${flip?"left":"right"}, [color] ${w}px, transparent ${w}px, transparent calc(50% - ${w}px), [color] calc(50% - ${w}px), [color] calc(50% + ${w}px), transparent calc(50% + ${w}px), transparent calc(100% - ${w}px), [color] calc(100% - ${w}px), [color] 100%)`;
            bgSize = `${sideLength}px ${sideLength}px`;
            break;
        case "dots":
            bgImage = `radial-gradient([color] ${dotSize/2-.4}px, transparent ${dotSize/2+.4}px)`;
            break;
        case "triangles":
            bgImage = `linear-gradient(${flip?-45:45}deg, transparent calc(50% - 0.1px), [color] calc(50% + 0.1px))`;
            break;
        case "custom":
            bgImage = `url("${customPatternImage?.src}")`;
            if (customPatternSizing !== "tile") {
                bgRepeat = "no-repeat";
                bgSize = IMAGE_SIZING_MAP[customPatternSizing];
            }
            break;
    }
    let hoverStyle = {};
    let hoverSizeValue = hoverSize;
    if (hoverShape === "glow") {
        const gradientPoints = [];
        for (let i = 0; i < 15; i++) {
            const normalized = mapRange(i, 0, 14, 0, 1);
            gradientPoints.push(`rgba(255, 255, 255, ${ease(1-normalized)}) ${mapRange(i,0,14,0,100)}%`);
        }
        hoverStyle = {
            maskImage: `radial-gradient(closest-side, ${gradientPoints.join(", ")})`
        };
        hoverSizeValue = hoverSize * 2;
    } else if (hoverShape === "circle") {
        hoverStyle = {
            borderRadius: "50%"
        };
    }
    return /*#__PURE__*/ _jsxs("div", {
        style: {
            position: "relative",
            borderRadius: radius,
            overflow: "hidden",
            backgroundImage: isCustom ? "" : bgImage.replace(/\[color\]/g, color),
            backgroundSize: bgSize,
            backgroundPosition: bgPosition,
            backgroundRepeat: bgRepeat,
            ...style
        },
        children: [isCustom && /*#__PURE__*/ _jsx("div", {
            style: {
                position: "absolute",
                inset: 0,
                backgroundColor: color,
                maskImage: bgImage,
                maskSize: bgSize,
                maskPosition: bgPosition,
                maskRepeat: bgRepeat,
                maskMode: customPatternMode
            }
        }), /*#__PURE__*/ _jsx("div", {
            style: {
                position: "absolute",
                inset: 0,
                maskImage: isCustom ? bgImage : bgImage.replace(/\[color\]/g, "white"),
                maskSize: bgSize,
                maskPosition: bgPosition,
                maskRepeat: bgRepeat,
                maskMode: isCustom ? customPatternMode : undefined,
                WebkitMaskImage: isCustom ? bgImage : bgImage.replace(/\[color\]/g, "white"),
                WebkitMaskSize: bgSize,
                WebkitMaskPosition: bgPosition,
                WebkitMaskRepeat: bgRepeat,
                WebkitMaskMode: isCustom ? customPatternMode : undefined
            },
            children: /*#__PURE__*/ _jsx("div", {
                style: {
                    position: "absolute",
                    top: isCanvas ? "50%" : 0,
                    left: isCanvas ? "50%" : 0,
                    transform: isCanvas ? "translate(-50%, -50%)" : undefined,
                    width: hoverSizeValue,
                    height: hoverSizeValue,
                    backgroundColor: hoverColor,
                    ...hoverStyle
                },
                children: /*#__PURE__*/ _jsx("div", {
                    style: {
                        display: "contents"
                    },
                    children: /*#__PURE__*/ _jsx(FollowCursor, {
                        enabled: true,
                        smoothing: smoothing,
                        horizontalAlignment: "center",
                        verticalAlignment: "center"
                    })
                })
            })
        })]
    });
}
ShimmerGrid.displayName = "Shimmer Grid";
addPropertyControls(ShimmerGrid, {
    color: {
        type: ControlType.Color,
        defaultValue: "rgba(153, 153, 153, 0.5)"
    },
    hoverColor: {
        type: ControlType.Color,
        defaultValue: "#FFF"
    },
    hoverSize: {
        type: ControlType.Number,
        defaultValue: 400,
        min: 1,
        max: 2e3,
        step: 1
    },
    hoverShape: {
        type: ControlType.Enum,
        defaultValue: "glow",
        options: ["glow", "circle"],
        optionTitles: ["Glow", "Circle"],
        displaySegmentedControl: true,
        title: "Shape"
    },
    patternPreset: {
        type: ControlType.Enum,
        defaultValue: "grid",
        options: Object.values(Pattern),
        optionTitles: ["Grid", "Checkerboard", "Horizontal Lines", "Vertical Lines", "Diagonal Lines", "Dots", "Triangles", "Custom"],
        title: "Pattern"
    },
    customPatternImage: {
        type: ControlType.ResponsiveImage,
        title: "Image",
        hidden: props => props.patternPreset !== "custom"
    },
    customPatternSizing: {
        type: ControlType.Enum,
        defaultValue: "tile",
        options: ["fill", "fit", "stretch", "tile"],
        optionTitles: ["Fill", "Fit", "Stretch", "Tile"],
        title: "Sizing",
        hidden: props => props.patternPreset !== "custom"
    },
    flip: {
        type: ControlType.Boolean,
        defaultValue: false,
        hidden: props => props.patternPreset !== "checkerboard" && props.patternPreset !== "triangles" && props.patternPreset !== "diagonalLines"
    },
    lineWidth: {
        type: ControlType.Number,
        defaultValue: 2,
        min: 1,
        step: 1,
        displayStepper: true,
        hidden: props => props.patternPreset !== "horizontalLines" && props.patternPreset !== "verticalLines" && props.patternPreset !== "diagonalLines" && props.patternPreset !== "grid"
    },
    tileSize: {
        type: ControlType.Number,
        defaultValue: 50,
        min: 1,
        step: 1,
        hidden: props => props.patternPreset === "custom" && props.customPatternSizing !== "tile"
    },
    dotSize: {
        type: ControlType.Number,
        defaultValue: 10,
        min: 1,
        step: 1,
        displayStepper: true,
        hidden: props => props.patternPreset !== "dots"
    },
    customPatternPosition: {
        type: ControlType.Enum,
        defaultValue: "center",
        options: ["topLeft", "topCenter", "topRight", "left", "center", "right", "bottomLeft", "bottomCenter", "bottomRight"],
        optionTitles: ["Top Left", "Top Center", "Top Right", "Left", "Center", "Right", "Bottom Left", "Bottom Center", "Bottom Right"],
        title: "Position",
        hidden: props => props.patternPreset !== "custom" || props.customPatternSizing === "stretch"
    },
    customPatternMode: {
        type: ControlType.Enum,
        defaultValue: "alpha",
        options: ["alpha", "luminance"],
        optionTitles: ["Alpha", "Luminance"],
        title: "Mode",
        hidden: props => props.patternPreset !== "custom"
    },
    smoothing: {
        type: ControlType.Number,
        defaultValue: 0,
        min: 0,
        max: 100,
        step: 1
    },
    radius: {
        type: ControlType.BorderRadius,
        defaultValue: "0px",
        description: "More components at [Framer University](https://frameruni.link/cc)."
    }
});

function getSideLength(hypotenuseLength) { // Check if input is a valid number
    if (typeof hypotenuseLength !== "number" || isNaN(hypotenuseLength) || hypotenuseLength <= 0) {
        return hypotenuseLength;
    } // Calculate the side length using the Pythagorean theorem
    // In a right isosceles triangle: side² + side² = hypotenuse²
    // So, side² = hypotenuse² / 2
    const sideLength = Math.sqrt(Math.pow(hypotenuseLength, 2) / 2); // Round the result to 2 decimal places
    return Number(sideLength.toFixed(2));
}

function mapRange(value, fromLow, fromHigh, toLow, toHigh) {
    if (fromLow === fromHigh) {
        return toLow;
    }
    const percentage = (value - fromLow) / (fromHigh - fromLow);
    return toLow + percentage * (toHigh - toLow);
}
export const __FramerMetadata__ = {
    "exports": {
        "default": {
            "type": "reactComponent",
            "name": "ShimmerGrid",
            "slots": [],
            "annotations": {
                "framerIntrinsicHeight": "400",
                "framerContractVersion": "1",
                "framerSupportedLayoutWidth": "fixed",
                "framerDisableUnlink": "*",
                "framerIntrinsicWidth": "400",
                "framerSupportedLayoutHeight": "fixed"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}