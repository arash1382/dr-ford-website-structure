import {
    jsx as _jsx
} from "react/jsx-runtime";
import {
    addPropertyControls,
    ControlType,
    RenderTarget
} from "framer";
import {
    useEffect,
    useRef,
    useMemo
} from "react";
import {
    useMotionValue,
    useSpring,
    animate
} from "framer-motion";
const ALIGNMENT = {
    left: 0,
    top: 0,
    center: .5,
    right: 1,
    bottom: 1
};
/**
 * @framerSupportedLayoutWidth any
 * @framerSupportedLayoutHeight any
 *
 * @framerDisableUnlink
 *
 * @framerIntrinsicWidth 400
 * @framerIntrinsicHeight 200
 */
export default function FollowCursor(props) {
    const {
        smoothing,
        enabled,
        horizontalAlignment,
        verticalAlignment,
        transition
    } = props;
    const isCanvas = RenderTarget.current() === RenderTarget.canvas;
    const id = generateInstanceId();
    const movementTransition = {
        damping: 100,
        stiffness: mapRange(smoothing, 0, 100, 2e3, 50)
    };
    const mouseX = useMotionValue(0);
    const mouseY = useMotionValue(0);
    const springX = useSpring(mouseX, movementTransition);
    const springY = useSpring(mouseY, movementTransition);
    const ref = useRef(null);
    const parentRef = useRef(null);
    const transformRef = useRef(null);
    const styleRef = useRef(null);
    const hasSpringRef = useRef(smoothing !== 0);
    const previousXRef = useRef(null);
    const previousYRef = useRef(null);
    const previousStyleTransformRef = useRef(null);
    const isInitializedRef = useRef(false);
    const previousScrollXRef = useRef(0);
    const previousScrollYRef = useRef(0);
    const opacityRef = useRef(1);
    const currentOpacityRef = useRef(0);
    useEffect(() => {
        hasSpringRef.current = smoothing !== 0;
    }, [smoothing]);
    useEffect(() => {
        let animationFrameId;
        const updateTransform = () => {
            if (isCanvas) return;
            animationFrameId = requestAnimationFrame(updateTransform);
            if (!parentRef.current || !styleRef.current) {
                return;
            }
            const xValue = (hasSpringRef.current ? springX.get() : mouseX.get()).toFixed(3);
            const yValue = (hasSpringRef.current ? springY.get() : mouseY.get()).toFixed(3); // Get computed styles to capture all existing transforms
            const computedStyle = window.getComputedStyle(parentRef.current);
            const transform = calculateTransform(parentRef.current, computedStyle, xValue, yValue, previousXRef.current, previousYRef.current, previousStyleTransformRef.current);
            const opacity = currentOpacityRef.current * opacityRef.current;
            transformRef.current = transform;
            styleRef.current.textContent = `
				[data-followcursor="${id}"] { 
					transform: ${transform} !important;
					${opacity<.995?`opacity: ${opacity} !important;`:""}
				}
			`;
            previousXRef.current = xValue;
            previousYRef.current = yValue;
            previousStyleTransformRef.current = parentRef.current.style.transform;
        };
        if (ref.current) {
            const container = ref.current.parentElement;
            if (container) {
                const parent = container.parentElement;
                if (parent) {
                    parentRef.current = parent;
                    parent.setAttribute("data-followcursor", id);
                }
            }
        } // Start the animation loop
        updateTransform(); // Cleanup function
        return () => {
            if (animationFrameId) {
                cancelAnimationFrame(animationFrameId);
            }
        };
    }, []);
    useEffect(() => {
        const handlePointerMove = event => {
            if (!parentRef.current) return;
            let setSpringsInstantly = false; // When initialized for the first time, animate opacity
            if (!isInitializedRef.current) {
                isInitializedRef.current = true;
                animate(currentOpacityRef.current, enabled ? 1 : 0, { ...transition,
                    onUpdate: latest => {
                        currentOpacityRef.current = latest;
                    }
                });
                setSpringsInstantly = true;
            } // Get the element's position without transforms
            const computedStyle = window.getComputedStyle(parentRef.current);
            const matrix = new DOMMatrix(computedStyle.transform);
            const rect = parentRef.current.getBoundingClientRect(); // Subtract the transform translation to get the original position
            const originalLeft = rect.left - matrix.m41;
            const originalTop = rect.top - matrix.m42; // Add scroll offsets to mouse position
            const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
            const scrollY = window.pageYOffset || document.documentElement.scrollTop; // Update previous scroll positions
            previousScrollXRef.current = scrollX;
            previousScrollYRef.current = scrollY;
            const mouseXPos = event.clientX + scrollX - (originalLeft + scrollX) - ALIGNMENT[horizontalAlignment] * rect.width;
            const mouseYPos = event.clientY + scrollY - (originalTop + scrollY) - ALIGNMENT[verticalAlignment] * rect.height;
            mouseX.set(mouseXPos);
            mouseY.set(mouseYPos);
            if (setSpringsInstantly) {
                springX.jump(mouseXPos);
                springY.jump(mouseYPos);
            }
        }; // Add scroll event handler to update position
        const handleScroll = () => {
            if (!parentRef.current || !isInitializedRef.current) return;
            const scrollX = window.scrollX || window.pageXOffset || document.documentElement.scrollLeft;
            const scrollY = window.scrollY || window.pageYOffset || document.documentElement.scrollTop; // Calculate scroll delta
            const deltaX = scrollX - previousScrollXRef.current;
            const deltaY = scrollY - previousScrollYRef.current; // Update previous scroll positions
            previousScrollXRef.current = scrollX;
            previousScrollYRef.current = scrollY; // Update position using scroll delta
            mouseX.set(mouseX.get() + deltaX);
            mouseY.set(mouseY.get() + deltaY);
        };
        window.addEventListener("pointermove", handlePointerMove);
        window.addEventListener("scroll", handleScroll);
        return () => {
            window.removeEventListener("pointermove", handlePointerMove);
            window.removeEventListener("scroll", handleScroll);
        };
    }, [enabled]);
    useEffect(() => {
        if (!styleRef.current || !parentRef.current) return;
        const computedStyle = window.getComputedStyle(parentRef.current);
        opacityRef.current = parseFloat(computedStyle.opacity) || 1;
        animate(currentOpacityRef.current, enabled && isInitializedRef.current ? 1 : 0, { ...transition,
            onUpdate: latest => {
                currentOpacityRef.current = latest;
            }
        });
    }, [enabled, transition]);
    return /*#__PURE__*/ _jsx("div", {
        ref: ref,
        style: { ...props.style
        },
        children: /*#__PURE__*/ _jsx("style", {
            ref: styleRef
        })
    });
}
FollowCursor.displayName = "Follow Cursor";
addPropertyControls(FollowCursor, {
    enabled: {
        type: ControlType.Boolean,
        defaultValue: true
    },
    smoothing: {
        type: ControlType.Number,
        defaultValue: 0,
        min: 0,
        max: 100,
        step: 1
    },
    horizontalAlignment: {
        type: ControlType.Enum,
        defaultValue: "center",
        options: ["left", "center", "right"],
        optionTitles: ["Left", "Center", "Right"],
        displaySegmentedControl: true,
        title: "Alignment"
    },
    verticalAlignment: {
        type: ControlType.Enum,
        defaultValue: "center",
        options: ["top", "center", "bottom"],
        optionTitles: ["Top", "Center", "Bottom"],
        displaySegmentedControl: true,
        title: " "
    },
    transition: {
        type: ControlType.Transition,
        defaultValue: {
            type: "spring",
            duration: .2,
            bounce: 0
        },
        description: "More components at [Framer University](https://frameruni.link/cc)."
    }
});
const CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
const generateInstanceId = () => {
    const id = useMemo(() => {
        let result = "";
        for (let i = 0; i < 13; i++) {
            result += CHARACTERS.charAt(Math.floor(Math.random() * CHARACTERS.length));
        }
        return result;
    }, []);
    return id;
};

function mapRange(value, fromLow, fromHigh, toLow, toHigh) {
    if (fromLow === fromHigh) {
        return toLow;
    }
    const percentage = (value - fromLow) / (fromHigh - fromLow);
    return toLow + percentage * (toHigh - toLow);
}

function calculateTransform(element, computedStyle, xValue, yValue, previousX, previousY, previousStyleTransform) {
    xValue = xValue || 0;
    yValue = yValue || 0;
    previousX = previousX || 0;
    previousY = previousY || 0; // Get transform
    const computedTransform = computedStyle.transform;
    const styleTransform = element.style.transform; // Subtract previous values from current values for a single transform
    const finalX = xValue - previousX;
    const finalY = yValue - previousY;
    const translateTransform = `translate(${finalX}px, ${finalY}px)`;
    let transform = translateTransform;
    if (styleTransform && styleTransform !== "none") {
        if (previousStyleTransform && previousStyleTransform !== "none") {
            transform = `${translateTransform} ${invertTransform(previousStyleTransform)} ${styleTransform}`;
        } else {
            transform = `${translateTransform} ${styleTransform}`;
        }
    }
    return computedTransform && computedTransform !== "none" ? `${transform} ${computedTransform}` : transform;
}

function invertTransform(transformString) {
    const transforms = transformString.match(/\w+\([^)]+\)/g) || [];
    const invertedTransforms = transforms.reverse().map(transform => {
        const [func, valuesString] = transform.match(/(\w+)\(([^)]+)\)/).slice(1);
        const values = valuesString.split(",").map(v => v.trim());
        const invertNumber = v => {
            const [_, sign, num, unit] = v.match(/^(-?)(\d*\.?\d+)(\D*)$/);
            return `${sign?"":"-"}${num}${unit}`;
        };
        switch (func.toLowerCase()) {
            case "translate":
            case "translate3d":
            case "translatex":
            case "translatey":
            case "translatez":
                return `${func}(${values.map(invertNumber).join(", ")})`;
            case "scale":
            case "scale3d":
                return `${func}(${values.map(v=>1/parseFloat(v)).join(", ")})`;
            case "scalex":
            case "scaley":
            case "scalez":
                return `${func}(${1/parseFloat(values[0])})`;
            case "rotate":
            case "rotatex":
            case "rotatey":
            case "rotatez":
                return `${func}(${invertNumber(values[0])})`;
            case "rotate3d":
                const rotateValues = values.map(parseFloat);
                return `${func}(${rotateValues[0]}, ${rotateValues[1]}, ${rotateValues[2]}, ${invertNumber(values[3])})`;
            case "skew":
            case "skewx":
            case "skewy":
                return `${func}(${values.map(invertNumber).join(", ")})`;
            case "matrix":
            case "matrix3d":
                console.warn(`Inverting ${func} is not supported. Returning original.`);
                return transform;
            default:
                console.warn(`Unknown transform function: ${func}. Returning original.`);
                return transform;
        }
    });
    return invertedTransforms.join(" ");
}
export const __FramerMetadata__ = {
    "exports": {
        "default": {
            "type": "reactComponent",
            "name": "FollowCursor",
            "slots": [],
            "annotations": {
                "framerDisableUnlink": "*",
                "framerSupportedLayoutHeight": "any",
                "framerIntrinsicHeight": "200",
                "framerContractVersion": "1",
                "framerIntrinsicWidth": "400",
                "framerSupportedLayoutWidth": "any"
            }
        },
        "__FramerMetadata__": {
            "type": "variable"
        }
    }
}
//# sourceMappingURL=./FollowCursor_Prod.map