# پک اسکیل‌های UI + سایت‌های رفرنس

هفت تا اسکیل که کمک می‌کنه سایت و اپی که با هوش مصنوعی می‌سازی بوی «AI» نده. بعدش هم هفت تا سایت رفرنس.

## اسکیل (Skill) یعنی چی؟

یه پوشه با یه فایل `SKILL.md` توش؛ بهش دستورالعمل و تجربه‌ی یه آدم حرفه‌ای رو می‌دی تا Claude وقتی کارت بهش می‌خوره، خودش لودش کنه و اون‌جوری کار کنه.

## چه‌جوری نصبش کنم؟

**راه ساده (دستی):** zip رو باز کن، پوشه‌ی اسکیل (همونی که `SKILL.md` توشه) رو کپی کن تو:

- `.claude/skills/` داخل پروژه‌ت، فقط برای همون پروژه
- یا `~/.claude/skills/` (توی ویندوز: `C:\Users\اسم-تو\.claude\skills\`)، برای همه‌ی پروژه‌ها

بعد Claude Code رو دوباره باز کن. بعد فقط کافیه کارت رو بگی؛ مثلاً «این صفحه رو طراحی کن».

**راه دستور (برای اونایی که پلاگین یا `npx` دارن):** دستورها دقیقاً از README خود هر ریپو برداشته شده، زیر هر اسکیل نوشتم.

> اسکیل شماره ۱ (frontend-design) توی zip نیست؛ لایسنس ریپوش اجازه‌ی پخش مجدد نمی‌ده، فقط لینک و دستور نصبش هست.

---

## وب

### ۱. frontend-design (Anthropic)
به درد چی می‌خوره: سایت و رابطی که Claude می‌سازه شکل «پیش‌فرض هوش مصنوعی» نداشته باشه؛ تایپوگرافی، رنگ و انیمیشن با شخصیت.
لینک: https://github.com/anthropics/claude-code/tree/main/plugins/frontend-design
نصب: `/plugin install frontend-design@claude-plugins-official`
(توی zip نیست، فقط لینک)

### ۲. ui-ux-pro-max
به درد چی می‌خوره: یه پایگاه دانش طراحی که Claude توش جستجو می‌کنه: ۷۹ استایل، ۱۹۲ پالت رنگ، ۷۴ ترکیب فونت، ۱۱۹ قانون UX، ۲۵ نوع چارت، ۲۲ استک. می‌تونه برای پروژه‌ت یه دیزاین‌سیستم کامل پیشنهاد بده. پایتون ۳ می‌خواد.
لینک: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
نصب:
```
/plugin marketplace add nextlevelbuilder/ui-ux-pro-max-skill
/plugin install ui-ux-pro-max@ui-ux-pro-max-skill
```
نکته برای نصب دستی: توی `SKILL.md` این اسکیل مسیر اسکریپت جستجو با `${CLAUDE_PLUGIN_ROOT}` نوشته شده که مخصوص نصب پلاگینه. اگه دستی کپی کردی و اسکریپت پیدا نشد، یا با دستور بالا نصب کن، یا به Claude بگو اسکریپت `scripts/search.py` کنار همون `SKILL.md` هست. (این مسیر رو تست نکردم.)

### ۳. taste-skill
به درد چی می‌خوره: ضد «اسلاپ». هنرجهت‌دهی برای لندینگ، سایت معرفی و پورتفولیو، با چک کردن نتیجه توی مرورگر واقعی. اسکیل اصلی `taste-skill` ه و کنارش چند تا اسکیل دیگه هم هست (redesign، soft، minimalist، brutalist و ...). برای اجرا Node نسخه‌ی ۲۲ به بالا و Chrome یا Edge می‌خواد. برای داشبورد و صفحه‌ی اپ نیست.
لینک: https://github.com/Leonxlnx/taste-skill
نصب:
```
npx skills add https://github.com/Leonxlnx/taste-skill
```
یا پلاگین Claude Code:
```
/plugin marketplace add Leonxlnx/taste-skill
/plugin install taste-skill@taste-skill
```

---

## اندروید

### ۴. android-skills (گوگل)
به درد چی می‌خوره: مجموعه‌ی رسمی گوگل از اسکیل‌های اندروید؛ توی پک ۳۰ تا اسکیل هست. بخش‌های مرتبط با UI: Jetpack Compose (adaptive، styles، performance)، edge-to-edge، Navigation 3، Wear OS Compose، ویجت‌ها (Glance) و ... هر اسکیل یه پوشه‌ی جداست؛ فقط اونایی که لازم داری رو کپی کن.
لینک: https://github.com/android/skills
نصب:
```
/plugin install android-skills --marketplace android/skills
```
یا با Android CLI: `android skills add --all`

### ۵. material-3-skill
به درد چی می‌خوره: ساخت UI مطابق Material Design 3 (Material You): توکن‌ها، بیش از ۳۰ کامپوننت، تم، چیدمان ریسپانسیو و ممیزی مطابقت با MD3. تمرکز اصلی روی Jetpack Compose، فلاتر هم پوشش داده.
لینک: https://github.com/hamen/material-3-skill
نصب:
```
npx --yes skills add hamen/material-3-skill --skill material-3 -y
```
یا:
```
/plugin marketplace add hamen/material-3-skill
/plugin install material-3@material-3-skill
```

---

## آیفون

### ۶. emil-kowalski skills
به درد چی می‌خوره: مجموعه‌ی ۱۵ تایی از Emil Kowalski (سابقه‌ی Vercel و Linear) برای جزئیات UI و انیمیشن: ساختن، بازبینی و بهینه کردن انیمیشن، `apple-design` (اصول طراحی اپل)، `write-swift`، `mobile-native` و `animate-expo` برای React Native. بخش بزرگی‌ش برای وب و رکت‌نیتیوه، نه فقط سوئیفت.
لینک: https://github.com/emilkowalski/skills
نصب:
```
npx skills@latest add emilkowalski/skills
```

### ۷. swiftui-expert (AvdLee)
به درد چی می‌خوره: راهنمای تخصصی SwiftUI برای iOS و macOS: مدیریت state، ساختار ویو، لیست و اسکرول، پرفورمنس، انیمیشن، لوکالایز، و Liquid Glass.
لینک: https://github.com/AvdLee/SwiftUI-Agent-Skill
نصب:
```
npx skills@latest add https://github.com/avdlee/swiftui-agent-skill --skill swiftui-expert-skill
```
یا:
```
/plugin marketplace add AvdLee/SwiftUI-Agent-Skill
/plugin install swiftui-expert@swiftui-expert-skill
```

---

## ۷ تا سایت رفرنس

**کامپوننت و انیمیشن**
- https://www.vengenceui.com : کامپوننت‌های ری‌اکتِ انیمیشنی برای لندینگ.
- https://animate-ui.com : کامپوننت‌های انیمیشنی اپن‌سورس (React، Tailwind، Motion)؛ با shadcn CLI نصب می‌شن.
- https://www.uilora.com : بیش از ۷۰۰ کامپوننت انیمیشنی برای Next.js و React Native، کپی و پیست.
- https://frameline.ai : المان و فایل طراحی آماده، برای اینکه چیزی که می‌سازی ظاهر پیش‌فرض AI نداشته باشه.

**آیکن و ۳بعدی**
- https://www.streamlinehq.com : کتابخونه‌ی بزرگ آیکن.
- https://lottiefiles.com : انیمیشن‌های Lottie سبک و آماده برای وب و اپ.
- https://spline.design : ابزار طراحی ۳بعدی توی مرورگر، با خروجی تعاملی.

---

لایسنس هر اسکیل کنار خودش توی پوشه هست (MIT برای شماره‌های ۲، ۳، ۵، ۶ و ۷؛ Apache-2.0 برای ۴). همه‌شون مال سازنده‌هاشونه؛ آپدیت‌ها رو از ریپوی خودشون بگیر.
